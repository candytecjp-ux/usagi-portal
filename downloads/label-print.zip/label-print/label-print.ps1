﻿# うさぎラベル印刷：ダウンロードした label_print_*.csv を b-PAC で印刷する
# 使い方：「ラベル印刷.bat」をダブルクリック（CSV を bat にドラッグしても可）
param([string]$CsvPath = '', [switch]$Is32 = $false)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.Application]::EnableVisualStyles()

$Here     = Split-Path -Parent $MyInvocation.MyCommand.Path
$Template = Join-Path $Here 'label_template.lbx'
$LogDir   = Join-Path $Here 'log'
$Title    = 'うさぎラベル印刷'
$ObjName  = 'テキスト1'          # テンプレート内の文字オブジェクト名
$bpoAutoCut = 0x1               # 1枚ごとにカット

function Say($msg, $icon = 'Information') {
  [void][System.Windows.Forms.MessageBox]::Show($msg, $Title, 'OK', $icon)
}
function Ask($msg) {
  return [System.Windows.Forms.MessageBox]::Show($msg, $Title, 'YesNoCancel', 'Question')
}

# --- 1. 印刷するファイルを決める ---------------------------------------
function Get-Downloads {
  try {
    $p = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path
    if ($p -and (Test-Path $p)) { return $p }
  } catch {}
  return (Join-Path $env:USERPROFILE 'Downloads')
}
if (-not $CsvPath) {
  $dl = Get-Downloads
  $f = Get-ChildItem -Path $dl -Filter 'label_print_*.csv' -File -ErrorAction SilentlyContinue |
       Where-Object { $_.Name -notlike '*.printed.csv' } |
       Sort-Object LastWriteTime -Descending | Select-Object -First 1
  if (-not $f) {
    Say "印刷するファイルが見つかりません。`n`n画面で「印刷ファイルを保存」を押してから、もう一度ダブルクリックしてください。`n（探した場所：$dl）" 'Warning'
    exit 1
  }
  $CsvPath = $f.FullName
}
if (-not (Test-Path $CsvPath)) { Say "ファイルがありません：$CsvPath" 'Error'; exit 1 }
$file = Get-Item $CsvPath

# --- 2. 中身を読む -------------------------------------------------------
try {
  $rows = @(Import-Csv -Path $CsvPath -Encoding UTF8)
} catch { Say "ファイルを読めませんでした。`n$($_.Exception.Message)" 'Error'; exit 1 }
$jobs = @()
foreach ($r in $rows) {
  $label = [string]$r.label
  $n = 0
  if ([string]::IsNullOrWhiteSpace($label) -or -not [int]::TryParse([string]$r.copies, [ref]$n) -or $n -lt 1 -or $n -gt 10) {
    Say "ファイルの中身がおかしいので印刷を止めました。`n（$label / $($r.copies)）`n画面で作り直してください。" 'Error'; exit 1
  }
  $label = ($label -replace "`r`n", "`n") -replace "`r", "`n"   # 改行をそろえる
  $jobs += [pscustomobject]@{ Label = $label; Copies = $n }
}
if (-not $jobs.Count) { Say 'ファイルに印刷する行がありません。' 'Warning'; exit 1 }

# --- 3. b-PAC を使えるか -------------------------------------------------
$doc = $null
try { $doc = New-Object -ComObject 'bpac.Document' } catch { $doc = $null }
if (-not $doc) {
  if ([Environment]::Is64BitProcess -and -not $Is32) {
    # 32bit 版の b-PAC だけ入っている場合に備えて、32bit の PowerShell でやり直す
    $ps32 = Join-Path $env:WINDIR 'SysWOW64\WindowsPowerShell\v1.0\powershell.exe'
    if (Test-Path $ps32) {
      & $ps32 -NoProfile -ExecutionPolicy Bypass -STA -File $MyInvocation.MyCommand.Path -CsvPath $CsvPath -Is32
      exit $LASTEXITCODE
    }
  }
  # どちらでも使えない → P-touch で手で印刷するための CSV（CP932・CRLF・BOMなし）をデスクトップに作る
  $desk = [Environment]::GetFolderPath('Desktop')
  $out  = Join-Path $desk ('ラベル_ptouch用_' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.csv')
  $enc  = [System.Text.Encoding]::GetEncoding(932, (New-Object System.Text.EncoderExceptionFallback), (New-Object System.Text.DecoderExceptionFallback))
  $lines = @('"ラベル","枚数"') + ($jobs | ForEach-Object { '"' + $_.Label.Replace('"', '""').Replace("`n", "`r`n") + '",' + $_.Copies })
  try {
    [System.IO.File]::WriteAllBytes($out, $enc.GetBytes(($lines -join "`r`n") + "`r`n"))
    $made = "P-touch Editor で手で印刷する場合のファイルをデスクトップに作りました：`n$out"
  } catch { $made = 'P-touch 用のファイルは作れませんでした（Shift-JIS にできない文字があります）。' }
  Say ("ラベルを自動で印刷する部品「b-PAC クライアント」がこのパソコンに入っていません。`n`n" +
       "フォルダ内の「はじめに.txt」の手順で入れてください（初回だけ）。`n`n" + $made) 'Warning'
  exit 3
}

# --- 4. 確認 -------------------------------------------------------------
$total = ($jobs | Measure-Object -Property Copies -Sum).Sum
$show  = ($jobs | Select-Object -First 25 | ForEach-Object { '  ' + ($_.Label -replace "`n", ' ') + '　× ' + $_.Copies }) -join "`n"
if ($jobs.Count -gt 25) { $show += "`n  …ほか $($jobs.Count - 25) 件" }
$age = [int]((Get-Date) - $file.LastWriteTime).TotalMinutes
$old = ''
if ($age -ge 60) { $old = "`n※ このファイルは $age 分前に保存したものです。新しく作ったなら、画面で保存し直してください。`n" }
$ans = Ask ("$($jobs.Count) 件・ラベル $total 枚を印刷します。$old`n$show`n`n" +
            "［はい］全部印刷　　［いいえ］1枚だけ試し印刷　　［キャンセル］やめる")
if ($ans -eq 'Cancel') { exit 0 }
$test = ($ans -eq 'No')

# --- 5. 印刷 -------------------------------------------------------------
if (-not (Test-Path $Template)) { Say "テンプレートがありません：$Template" 'Error'; exit 1 }
if (-not $doc.Open($Template)) { Say "テンプレートを開けませんでした：$Template" 'Error'; exit 1 }
try {
  # プリンター：テンプレートの指定 → 見つからなければ QL-800 → QL-600 → ほかの QL
  $names = @()
  try { $names = @(Get-CimInstance Win32_Printer | Select-Object -ExpandProperty Name) } catch {
        $names = @(Get-WmiObject Win32_Printer | Select-Object -ExpandProperty Name) }
  $cur = ''
  try { $cur = [string]$doc.Printer.Name } catch {}
  $ql  = @($names | Where-Object { $_ -match 'QL-' })
  $pick = $null
  if ($cur -and ($names -contains $cur)) { $pick = $cur }
  else { $pick = @($ql | Where-Object { $_ -match 'QL-8' }) + @($ql | Where-Object { $_ -match 'QL-6' }) + $ql | Select-Object -First 1 }
  if (-not $pick) { throw "Brother QL のプリンターが見つかりません。電源とUSBを確認してください。（見つかったプリンター：$($names -join '、')）" }
  if ($pick -ne $cur) { [void]$doc.SetPrinter($pick, $true) }

  $obj = $doc.GetObject($ObjName)
  if (-not $obj) { throw "テンプレートに「$ObjName」がありません。" }

  if ($test) { $jobs = @([pscustomobject]@{ Label = $jobs[0].Label; Copies = 1 }) }
  [void]$doc.StartPrint('', $bpoAutoCut)
  foreach ($j in $jobs) {
    $obj.Text = $j.Label -replace "`n", "`r`n"   # ラベル上で改行
    [void]$doc.PrintOut($j.Copies, $bpoAutoCut)
  }
  if (-not $doc.EndPrint()) { throw "印刷できませんでした（エラー番号 $($doc.ErrorCode)）。プリンターの電源・ロール紙を確認してください。" }
} catch {
  try { $doc.Close() | Out-Null } catch {}
  Say "印刷を止めました。`n$($_.Exception.Message)" 'Error'
  exit 1
}
$doc.Close() | Out-Null

# --- 6. 記録して、同じファイルを二度印刷しないよう名前を変える -------------
try {
  if (-not (Test-Path $LogDir)) { New-Item -ItemType Directory -Path $LogDir | Out-Null }
  $log = Join-Path $LogDir ('print_' + (Get-Date -Format 'yyyyMM') + '.csv')
  $mode = if ($test) { 'テスト' } else { '本番' }
  $stamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
  $jobs | ForEach-Object { "$stamp,$mode,$pick,`"$(($_.Label -replace "`n", ' ').Replace('"','""'))`",$($_.Copies)" } |
    Add-Content -Path $log -Encoding UTF8
} catch {}
if ($test) {
  Say "試し印刷を1枚送りました。`n問題なければ、もう一度ダブルクリックして［はい］を押してください。"
} else {
  try { Rename-Item -Path $CsvPath -NewName ($file.BaseName + '.printed.csv') } catch {}
  Say "$total 枚を印刷に送りました。"
}
exit 0

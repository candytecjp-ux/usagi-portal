@echo off
rem Usagi label print - double click (or drop a label_print_*.csv on this file)
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "%~dp0label-print.ps1" -CsvPath "%~1"

@echo off
rem Create a desktop shortcut for label printing (first time only)
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$d=[Environment]::GetFolderPath('Desktop'); $s=(New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $d ([string][char]0x30E9+[char]0x30D9+[char]0x30EB+[char]0x5370+[char]0x5237+'.lnk'))); $s.TargetPath='%~dp0print.bat'; $s.WorkingDirectory='%~dp0'; $s.IconLocation='%SystemRoot%\System32\imageres.dll,46'; $s.WindowStyle=7; $s.Save()"
echo Done. Check the desktop for the shortcut.
pause
